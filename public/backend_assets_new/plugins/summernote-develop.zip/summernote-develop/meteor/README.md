Packaging [http://hackerwins.github.io/summernote/](http://hammerjs.github.io/) for [Meteor.js](http://meteor.com).


# Meteor

If you're new to Meteor, here's what the excitement is all about -
[watch the first two minutes](https://www.youtube.com/watch?v=fsi0aJ9yr2o); you'll be hooked by 1:28.

That screencast is from 2012. In the meantime, Meteor has become a mature JavaScript-everywhere web
development framework. Read more at [Why Meteor](http://www.meteorpedia.com/read/Why_Meteor).


# Issues

If you encounter an issue while using this package, please CC @dandv when you file it in this repo.


# DONE

* Instantiation test


# TODO

* Make sure library works with Meteor's reactivity - for example to auto-save to a collection
transparently after the text changes.

* Tests ensuring correct event handling on template re-rendering
